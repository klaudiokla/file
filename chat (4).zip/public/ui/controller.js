(function() {

var _GET = (function() {
    var _get = {};
    var re = /[?&]([^=&]+)(=?)([^&]*)/g;
    while (m = re.exec(location.search))
        _get[decodeURIComponent(m[1])] = (m[2] == '=' ? decodeURIComponent(m[3]) : true);
    return _get;
})();

var noAgentStatus = false;

var storedMessages = [];
var saveMessage = function(msg){
	try{
		storedMessages.push(msg);
		sessionStorage.setItem('JTELChatMessages', JSON.stringify(storedMessages));
		console.log('saveMessage: ', msg);
	}catch(error){
		console.log(error);
	}
}

var cleanMessages = function(){
	try{
		storedMessages = [];
		sessionStorage.setItem('JTELChatMessages', '[]');
	}catch(error){
		console.log(error);
	}
}

var restoreMessages = function() {
	var retrievedMessages = sessionStorage.getItem('JTELChatMessages');
	if(!retrievedMessages) return;
	var retrievedMessagesArray = JSON.parse(retrievedMessages);
	console.log('retrievedMessages: ', retrievedMessagesArray);
	for (var i = 0; i < retrievedMessagesArray.length; i++) {
		var messageEntry = retrievedMessagesArray[i];
		storedMessages.push(messageEntry);
    	console.log(messageEntry);
    	var sendDate = window.moment(messageEntry.sendDate).format("HH:mm");
    	var tmpl;
		if( messageEntry.messageId && ( messageEntry.messageId.indexOf("jtel_") == 0 ) ) {
			templ = JtelUI.leftMsgTpl( messageEntry.body, sendDate, JtelUI.leftStyle, messageEntry.AgentUID, messageEntry.AgentNickName );
		}
		else {
			templ = JtelUI.msgTpl( messageEntry.body, sendDate, JtelUI.rightStyle, messageEntry.messageId );
		}
		$("#display").append(templ).show("slow");
	}
	$("#display").animate({
		scrollTop : $("#display").prop("scrollHeight") + 5000
	}, 1000);
}

function geti18n( key,defaultvalue ){
	try{
		var language = (navigator.language || navigator.userLanguage).substring(2,0);
		return JtelUI.data[ key+'#'+language ] || JtelUI.data[ key ] || defaultvalue;
	}
	catch( error ) {
		return defaultvalue;
	}
};

function showStatus( status, defMessage ){
	$("#display").append(
		JtelUI.leftMsgTpl( geti18n( status, defMessage ), window.moment().format("HH:mm"), JtelUI.leftStyle, '', '' ) ).show("slow");
		$("#display").animate({scrollTop : $("#display").prop("scrollHeight") + 5000}, 1000 );
}

function hideEditor(){
	$("#label").hide();
	$("#editor").hide();
	$("#sendBtn").hide();
}

function showNoAgentStatus(){
	hideEditor();
	noAgentStatus = true;
	showStatus('noAgents','Sorry, no agents available.');
};

function showOutOfServiceTimeStatus(){
	hideEditor();
	noAgentStatus = true;
	showStatus('outOfService','Sorry, out of service.');
};

function showWelcomeStatus(){
	$("#label").hide();
	$("#editor").show();
	$("#sendBtn").show();
	noAgentStatus = false;
	if((JtelUI.data.expired!==false)||(storedMessages.length == 0)) showStatus('welcomeMessage','Welcome!');
	$("#editor").attr("placeholder",geti18n("editorPlaceholder","..."));
}

function showTypingStatus(msgdata){
	var agentUID = msgdata.AgentUID;
	var agentNickName = msgdata.AgentNickName;
	var messageToShow = geti18n('agentTyping','Agent typing...');
	if( agentNickName ) {
		messageToShow = messageToShow.replace( '\$agent', agentNickName );
	}
	else if( agentUID ) {
		messageToShow = messageToShow.replace( '\$agent', agentUID );
	}
	$("#label").html(JtelUI.validHTML(messageToShow));
	if(msgdata.body == 'write'){
		$("#label").show();
	}else{
		$("#label").hide();
	}
	setTimeout(function(){$("#label").hide();}, 3000);
}

function showError(errorInfo){
	$("#label").html(JtelUI.validHTML(errorInfo)).show();
}

function closeChatWindow(){
	console.log(_GET['origin']);
	parent.postMessage('','*');
	sessionStorage.setItem("JTELChatCookie", null);
	//setTimeout(window.parent.JTEL.closeChatWindow, 3000);
}

function getLastChatCookie()
{
	return sessionStorage.getItem("JTELChatCookie");
}

function drawMessage( message )
{
	var moment = window.moment().format("HH:mm");
	$("#typingLabel").hide();
	$("#display").append( JtelUI.leftMsgTpl( message.body, moment, JtelUI.leftStyle, message.AgentUID, message.AgentNickName ) ).show("slow");
	$("#display").animate( {scrollTop : $("#display").prop("scrollHeight") + 5000 }, 1000 );
}

JtelUI = {
	data: null,
	receivedMessages: [],

	bind : function() {
		var clientHash = _GET['hash'];
		var baseUri = _GET['base'];
		var providerData = _GET['pdata'];

		if (!clientHash||!baseUri) {
			console.log('hash or base parameters missing');
		} else {
			$.post(
				baseUri.replace('ws:','http:').replace('wss:','https:')+'/chatInit',
				{q: clientHash, cookie: getLastChatCookie(), pdata: providerData},
				function(data) {
					console.log('chatInit', data);
					if(data && !data.expired) restoreMessages();

					if (data.error && data.error == 'true') {
						alert('Error [' + clientHash + '] - ' + data.info);
						document.body.innerHTML = ""
					} else {
						$("#jtelCClientTitle").html(data.Title)

						$("#closeBtn").on('click',function() {
							cleanMessages();
							JTELCC.disconnect({type:'clientclose'});
							closeChatWindow();
						});

						JtelUI.data = data;
						if((data.bOpeningTimes==0) || (data.bWorkDay==0)){
							showOutOfServiceTimeStatus();
							return;
						}
						else if(data.agentsnumber==0){
							showNoAgentStatus();
							return;
						}
						else{
							showWelcomeStatus();
						}

						$("#sendBtn").on("click",function() {
							JtelUI.sendTextMessage($("#editor").val());
							$("#editor").val('');
						});

						$("#editor").on('keypress',function(e) {
							if ((e.keyCode == 13 || e.keyCode == 10) && e.ctrlKey) {
								e.stopPropagation();
								e.cancelBubble = true;
								JtelUI.sendTextMessage($("#editor").val());
								$("#editor").val('');
							}
						});

						$("#editor").focus();
						$("#typingLabel").hide();

						var options = {
							callback: function (value){
								JTELCC.composing(value);
							},
							wait: 1000,
							highlight: false,
							allowSubmit: false,
							captureLength: 2
						 }
						 $("#editor").typeWatch( options );

						JtelUI.connect();
					}
				}).fail(function() {
					showError("Can't connect to server.");
				});
		}
	},

	sendTextMessage : function(message) {
		if (message) {
			var moment = window.moment().format("HH:mm");
			var messageId  =  JTELCC.createClientId();
			$("#display").append(JtelUI.msgTpl(message,moment,JtelUI.rightStyle,messageId)).show("slow");
			$("#editor").html("");
			$("#display").animate({
				scrollTop : $("#display").prop("scrollHeight") + 5000
			}, 1000);

			var templ = {};
			templ.type = 'message';
			templ.sendDate = window.moment().format();
			templ.messageId =  messageId;
			templ.body=message;
			saveMessage(templ);
			templ.udata ={name:"", email:"", address:""};
			JTELCC.send(message, templ);
		}
	},

	onMessage : function(message) {
		var stopTypingTimer; 
		var msgdata = message;
		if (typeof msgdata === 'string' || msgdata instanceof String)
			try{ 
				msgdata = JSON.parse(message);}
			catch(err){
				console.log(err);
				console.log(message);
				return;
			}

		var messageType = msgdata.type || 'unknown' ;
		
		if(messageType == 'agentstatus'){
			if(msgdata.agentsnumber >0 && noAgentStatus){
				showWelcomeStatus();
			}
		}else if(messageType == 'composing'){
			showTypingStatus(msgdata);
		}else if(messageType == 'savedAtServer'){
			var messageId = msgdata.messageId;
			var el = $('#' + messageId + '_pic');
			if(el){
				el.attr('src', './okGray.png');
			}
		}else if(messageType == 'agentread'){
			if (msgdata) {
				$(".msgStatus").map(function(){
					$(this).attr('src', './okGreen.png');
				});
			}
		}else if(messageType == 'debug'){
		}else if(messageType == 'agentclose') {
			var msg = { body: geti18n('bye','Bye!') };
			drawMessage( msg );
			hideEditor();
			cleanMessages();
			sessionStorage.setItem("JTELChatCookie", null);
		}else if(messageType == 'noagentclose'){
			var msg = { body: geti18n('byeNoAgent','Bye!') };
			drawMessage( msg );
			hideEditor();
			cleanMessages();
			sessionStorage.setItem("JTELChatCookie", null);
		}else if(messageType == 'message') {
			if(JtelUI.canProcessMessage(msgdata.messageId)){
				drawMessage(msgdata);
				saveMessage(msgdata);
				JTELCC.send('', {type:'clientread', messageId:msgdata.messageId});
			}
		}
	},
	connect : function() {
		var uri = _GET['base'];
		if( !JtelUI.data.url ) JtelUI.data.url = uri + "/ws";

		JtelUI.data.cookie = getLastChatCookie();
		JTELCC.setMetadata( JtelUI.data );

		JTELCC.connect(JtelUI.data,
			function(status) {
				console.log("connected with status : " + status);
				$("#label").hide();
			}, 
			JtelUI.onMessage,
			function(status) {
				console.log("connection closed - reconnect");
				JTELCC.reconnect();
			}, 
			function(evt) {
				console.log(evt);
				console.log("ws error try to reconnect after 3 seconds");
				JTELCC.reconnectAfter(3000);
				showError("Connecting...");
			});
	},
	
	canProcessMessage : function(messageId){
		for(var  i = 0; i < JtelUI.receivedMessages.length;i++){
			if(JtelUI.receivedMessages[i] == messageId){
				return false;
			}
		}
		JtelUI.receivedMessages.push(messageId);
		return true;	
	},

	validHTML: function(html) {
		return $('<div/>').text(html).html();
	},

	msgTpl: function(lastMsg, lastMsgDate, msgStyle, msgId){
		var lastMsgValid = JtelUI.validHTML(lastMsg);
		return '<div style="clear: both;"></div>'
+'<div class="ui card" style="padding:4px;min-height:25px;'+msgStyle+';min-width:70%;max-width:80%;">'
+ '<div class="content" style="padding:0px;margin:0px">'
+  '<div class="description" style="font-size:13.6px;color:#262626;word-wrap: break-word;">'
+  lastMsgValid
+  '</div>'
+ '<div class="extra content" style="margin-top:0px">'
+  '<div class="right floated" style="margin-left:65px;">'
+   '<span class="time" style="color:#262626;font-size:9px;">'+lastMsgDate+'</span>'
+   '<img alt="" id="'+msgId+'_pic" style="width:16px;height:16px;" class="ui avatar image msgStatus" src="./loading.gif" />'
+  '</div>'
+ '</div>'
+'</div>';
	},

	leftMsgTpl: function( lastMsg, lastMsgDate, msgStyle, agentUID, agentNickName ) {
		var agentNameToShow = '';
		if( agentNickName && agentNickName != '' ) {
			agentNameToShow = JtelUI.validHTML( agentNickName );
		}
		else if ( agentUID && agentUID != '' ) {
			agentNameToShow = JtelUI.validHTML( agentUID );
		}
		var lastMsgValid = JtelUI.validHTML( lastMsg );
		return '<div style="clear: both;"></div>'
+'<div class="ui card" style="padding:4px;min-height:25px;'+msgStyle+';max-width:80%;min-width:60%;width:auto">'
+ '<div class="content" style="padding:0px;">'
+  '<div class="description" style="font-size:13.6px;color:#262626;word-wrap: break-word;">'
+	lastMsgValid
+  '</div>'
+ '<div class="extra content" style="margin-top:0px">'
+  '<div class="right floated" style="margin-left:65px;">'
+    '<span class="time" style="color:#F17735;font-size:9px;font-weight:bold;">' + agentNameToShow + ' </span> '
+    '<span class="time" style="color:#262626;font-size:9px;">' + lastMsgDate + '</span>'
+  '</div>'
+ '</div>'
+'</div>';
	},   

	rightStyle: "border-radius:5px;margin-bottom:5px;float:right;margin-right:15px;color:black;box-shadow:0 1px 2px 0 rgba(34,36,38,.15);-webkit-box-shadow:0 1px 2px 0 rgba(34,36,38,.15);-moz-box-shadow:0 1px 2px 0 rgba(34,36,38,.15);background:rgba(225,245,254,.92);",
	leftStyle: "border-radius:5px;color:black;margin-bottom:5px;float:left;margin-left:15px;box-shadow:0 1px 2px 0 rgba(34,36,38,.15);-webkit-box-shadow:0 1px 2px 0 rgba(34,36,38,.15);-moz-box-shadow:0 1px 2px 0 rgba(34,36,38,.15);background:rgba(0, 255, 0, 0.3);"

}})();