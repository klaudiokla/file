(function() {

var iconClicked = false;
function initChatIcon() {
		iconClicked = false;
		document.getElementById("jtelChatIcon").src = JTEL.baseResourceURI+'images/messages.svg';
		JTEL.holder.style.backgroundColor = "white";
		var cc =  document.getElementById(JTEL.chatHash);
		if(cc)cc.parentNode.removeChild(cc);
};

function clickChatIcon(event) {
	if(!iconClicked){
		iconClicked = true;
		document.getElementById("jtelChatIcon").src = JTEL.baseResourceURI+'images/close.svg';
		JTEL.holder.style.backgroundColor = "#f2711c";
		JTEL.embedChatClient();
	}
	else initChatIcon();
};

JTEL = {
	chatHash: "JTELChatFrameID",
	baseWSURI: "",
	baseResourceURI: "",
	providerData: {},
	isAgentAvailable : function(data, callback){
		var url = data.BaseWSURI.replace('ws:','http:').replace('wss:','https:')+'/rest';
		var xhttp = new XMLHttpRequest();
		data.type='isAgentAvailable';
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				console.log('isAgentAvailable', this.responseText);
				var json = JSON.parse(this.responseText);
				callback( json.result );
			}
		};
		xhttp.open('POST', url, true);
		xhttp.setRequestHeader('Content-type', 'application/json');
		var json = JSON.stringify(data);
		xhttp.send(json);
	},
	initChat : function(config){
		window.onload = function() {
			if(!config || !config.Hash){
				alert('JTEL-Chat : No Chat Hash specified.');
			}else{
				JTEL.chatHash = config.Hash;
				JTEL.baseWSURI = config.BaseWSURI;
				if(config.BaseResourceURI){
					JTEL.baseResourceURI = config.BaseResourceURI+(config.BaseResourceURI.endsWith("/")?"":"/");
				}

				if(config.pdata){
					JTEL.providerData = config.pdata;
					JTEL.providerData.url = (window.location != window.parent.location) ? document.referrer: document.location.href;
				}

				var holder = document.createElement('div');
				holder.style.position = "fixed";
				holder.style.bottom = "60px";
				holder.style.right = "40px";
				holder.style.width = "60px";
				holder.style.height = "60px";
				holder.style.borderRadius = "5px";
				holder.style.boxShadow = "0px -4px 74px -5px rgba(0,0,0,0.75)";
				holder.style.zIndex = 5000000;
				holder.style.cursor = 'pointer';
				holder.innerHTML = "<img id='jtelChatIcon' src='"+JTEL.baseResourceURI+"images/messages.svg' style='width:60px;' />";
				holder.style.backgroundColor = "white";
				holder.addEventListener('click', clickChatIcon);
				JTEL.holder = holder;
				document.body.appendChild(holder);

				if (typeof(Storage) !== "undefined") {
					var cookie = localStorage.getItem("JTELChatCookie");
					console.log(cookie);
					if(cookie && cookie.length>0){
						clickChatIcon();
					}
				} else {
					console.log("No Web Storage support.");
				}
			}
		};

		function receiveInterdomainMessage(event)
		{
			console.log('origin:'+event.origin+', data:'+event.data);
			localStorage.setItem("JTELChatCookie", event.data);
			if(!(event.data && event.data.length > 0)){
				JTEL.closeChatWindow();
			}
		}

		window.addEventListener("message", receiveInterdomainMessage, false);
	},

	embedChatClient : function(){
		 var chatClient = document.createElement('div');
		 chatClient.id = JTEL.chatHash;
		 chatClient.style.cssText="resize:both;overflow:auto;margin:0px;padding:0px;min-width:400px;min-height:500px;";
		 chatClient.style.position = "fixed";
		 chatClient.style.bottom = "40px";
		 chatClient.style.right = "40px";
		 chatClient.style.width = "400px";
		 chatClient.style.height = "600px";
		 chatClient.style.borderRadius = "5px";
		 chatClient.style.backgroundColor = "white";
		 chatClient.style.boxShadow = "0px -4px 74px -5px rgba(0,0,0,0.75)";
		 chatClient.style.zIndex = 5000000;
		 chatClient.innerHTML = "<iframe  src='"+JTEL.baseResourceURI+"ui/index.html?hash=" + JTEL.chatHash 
		 	+ "&base=" + JTEL.baseWSURI
		 	+ "&origin=" + window.location.origin
		 	+ "&pdata=" + encodeURIComponent(JSON.stringify(JTEL.providerData))
		 	+ "' style='height:99%;width:100%;margin:0px;padding:0px;' frameBorder=\"0\" scrolling=\"no\"><iframe>";

		 document.body.appendChild(chatClient);
	},

	closeChatWindow : function(){
		var cc =  document.getElementById(JTEL.chatHash);
		if(cc) cc.parentNode.removeChild(cc);
		if (typeof(Storage) !== "undefined")localStorage.setItem("JTELChatCookie", "");
		initChatIcon();
	}

}})();