var JTELCC = (function () {
	var me;

	var log = function(msg){
		if (typeof msg === 'string' || msg instanceof String)
			console.log('JTELCC: '+msg);
		else
			console.log( 'JTELCC:', msg);
	}

	var default_callback = function(msg){
		log('callback not set');
	}

	var closed_callback = function(msg){
		log('closed');
	}

	var cloneMessage = function(obj) {
		var copy;
		if (null == obj || "object" != typeof obj) return obj;
		if (obj instanceof Date) {
				copy = new Date();
				copy.setTime(obj.getTime());
				return copy;}
		if (obj instanceof Array) {
			copy = [];
			for (var i = 0, len = obj.length; i < len; i++) {
				copy[i] = clone(obj[i]);
			}
		 	return copy;
		}
		if (obj instanceof Object) {
			copy = {};
			for (var attr in obj) {
				if (obj.hasOwnProperty(attr)) copy[attr] = cloneMessage(obj[attr]);
			}
			return copy;
		}
		throw new Error("Unable to copy obj!");
	}

	var isConnected = function () {
		if( me.ws && (me.ws.readyState == 1) )
			return true;
		return false;
	}

	var saveSessionCookie = function(cookie){
		if(!cookie)return;
		if(cookie=='null')return;
		if( me.cookie != cookie){
			me.cookie = cookie;
			if (typeof(Storage) !== "undefined") {
				sessionStorage.setItem("JTELChatCookie",cookie);
				if(parent)parent.postMessage(cookie,'*');
				console.log('session storage cookie',cookie);
			}
		}
	}

	var onopen = function(){
		me.reconnectScheduled = false;
		var msg = {};
		if(me.metadata.Hash) msg.Hash = me.metadata.Hash;
		if(me.metadata.UsersID) msg.UsersID = me.metadata.UsersID;
		if(me.metadata.AgentUID) msg.AgentUID = me.metadata.AgentUID;
		if(me.metadata.AgentNickName) msg.AgentNickName = me.metadata.AgentNickName;
		if(me.metadata.pdata) msg.pdata = me.metadata.pdata;
		if(me.metadata.udata) msg.udata = me.metadata.udata;
		msg.type = 'onopen';
		msg.language = navigator.language;
		msg.cookie = me.cookie;
		try{
			var stringified = JSON.stringify(msg);
			log('send ' + stringified);
			me.ws.send(stringified);
		}catch(err){
			log(err);
			me.onopen_callback('ERROR:'+err);
		};
		sendQueued();
		me.onopen_callback('OK');
	}

	var onclose = function(){
		log('onclose');
		if(me.onclose_callback)me.onclose_callback();
	}

	var processMessage = function( msg ){
		if( msg.cookie && ( (msg.type == "sessioninfo") || (msg.type == "agentstatus") ) ){
			saveSessionCookie( msg.cookie );
		}
		
		if( msg.type == "agentstatus" ){
			me.agentsnumber = msg.agentsnumber;
			return false;
		}
		if( msg.type == "debug" ){
			log(msg);
			return true;
		}
		if( msg.type == "agentclose" ){
			log(msg);
			me.disconnect();
			return false;
		}
		if( msg.type == "noagentclose" ){
			log(msg);
			me.disconnect();
			return false;
		}
		if( msg.type == "closed" ){
			log(msg);
			me.disconnect();
			return true;
		}
		return false;
	}

	var connectme = function( onopen_callback ){
 		var ws = new WebSocket(me.url);
 		me.ws = ws;
 		ws.onopen = onopen;
 		if(onopen_callback)	ws.onopen =	onopen_callback;		
		ws.onmessage = onmessage;
		ws.onclose = onclose;
		ws.onerror = onerror;

		log('connecting...');
	}

	var connectAfterTimeout = function(){
		me.reconnectScheduled = false;
		log("JTELCC: try to connect after timeout");
		connectme();
	}

	var onmessage = function(evt){
		var json = JSON.parse(evt.data);
		log('onmessage ' + evt.data);
		if(json){
			if(!processMessage(json)){
				if(me.onmessage_callback) {
					me.onmessage_callback(json);
				}
			}
		}
	}

	var onerror = function(evt){
		log('onerror');        
		if(me.onerror_callback)me.onerror_callback(evt);
	}

	var trySend = function(msg,queue){
		msg.cookie = me.cookie;
		try{
			var stringified = JSON.stringify(msg);
		}catch(err){
			log(err);
			return false;
		};
		if(!isConnected()){
			if(queue){
				me.delayedMessages.push(msg);
				log("queued:"+stringified);
			}
			return false;
		}
		try{
			me.ws.send(stringified);
			log('sent ' + stringified);
		}catch(err){
			if(queue){
				me.delayedMessages.push(msg);
				log("queued:"+stringified);
			}
			log(err);
		};
		return false;
	}

	var send = function(template, body){
		try{
			template.body = body;
			template.language = navigator.language;
			template.Hash = me.metadata.Hash;
			return trySend(template,true);
		}catch(err){log(err);};
		return false;
	}

	var isAgentsAvailable = function(){
		return (me.agentsnumber > 0);
	}

	var sendQueued = function(msg){
		while(me.delayedMessages.length != 0){
			if(!trySend(me.delayedMessages[0],false)) return;
			me.delayedMessages.shift();
		}
	}

	me = {
		metadata:{},
		delayedMessages:[],
		reconnectScheduled:false,
		closedByClient:false,
		ws: null,
		url: null,
		agentsnumber: 0,
		onopen_callback: default_callback,
		onmessge_callback: default_callback,
		onclose_callback: default_callback,
		onerror_callback: default_callback,
		cookie:null,

		connect: function(metadata, cb_open, cb_msg, cb_close, cb_error) {
			if (!("WebSocket" in window)){
				log('WebSocket is not supported');
				return false;
			}

			if(!cb_open){
				log('cb_open not set');
				return false;	
			}

			if(!cb_msg){
				log('cb_msg not set');
				return false;	
			}

			me.url = metadata.url;
			if(metadata.cookie) me.cookie = metadata.cookie;
			me.onopen_callback = cb_open;
			me.onmessage_callback = cb_msg;
			if(cb_close)me.onclose_callback = cb_close;
			if(cb_error)me.onerror_callback = cb_error;

			connectme();
		},

		disconnect: function (msg) {
			me.closedByClient=true;
			if(!me.ws) return;
			me.ws.onclose = closed_callback;
			me.ws.onerror = closed_callback;

			if(msg && msg.type=='clientclose'){
				JTELCC.send("disconnect",msg);
				log('wait disconnect form server');
				return;
			}

			me.ws.close();
			me.ws = null;
			log('disconnected');
		},

		isConnected: function (cookie) {
			if(cookie){
				if(me.cookie != cookie) return false;
			}
			return isConnected();
		},

		reconnect: function (onopen_callback) {
			if(me.reconnectScheduled){
				log("already scheduled reconnection")
				return;
			}
			connectme(onopen_callback);
		},

		reconnectAfter: function (timeout) {
			if(me.reconnectScheduled){
				log("already scheduled reconnection")
				return;
			};
			me.reconnectScheduled = true;
			setTimeout(connectAfterTimeout, timeout);
		},

		composing: function (msg) {
			send({type:'composing'}, msg);
		},

		send: function (msg, template) {
			if(template) {
				send(template,msg);}
			else{
				 send({type:'message'},msg);}
		},

		setMetadata: function (app) {
			me.metadata = app;
		},

		createClientId: function(){
			var clientId = "";
			var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
			for( var i=0; i < 10; i++ ){
				 clientId += possible.charAt(Math.floor(Math.random() * possible.length));
			}
			return clientId;
		},

		createJtelClientId: function(){
			var id = me.createClientId();
			return "jtel_" + id;
		}
	};

	return me;
}());