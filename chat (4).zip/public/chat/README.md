This folder contains the  files necessary to create the chat client.

cc.js is the main chat controller. Responsible of websocket communication with the server.

typewatch.js is a js file used to watch when the user types in the chat textfield. This allows us to create the "typing" message
on the customer client.

	interface

	setMetatdata(chatMetadata)
	connect(url, callback_open, callback_msg, callback_close, callback_error )
	reconnect(callback_open) - with the same credentials
	disconnect() - drop connection (not required) 
	composing() - inform the chat server about client activity
	isAgentsAvailable() - is agents available 

	message types:

--> to server
	'onopen','composing','message',

<-- to browser
	'sessioninfo' - becomes session cookie 
	'agentstatus' - information about availabel agents
	'message' - message from agent
	'composing' - agent typing
	'error' - error message

	'cookie' - <session>
	'body' - <message content>
	'Hash' - chat hash 

TODO
should be used library instead of direct websockets
or implemented the following
https://stackoverflow.com/questions/26971026/handling-connection-loss-with-websockets

